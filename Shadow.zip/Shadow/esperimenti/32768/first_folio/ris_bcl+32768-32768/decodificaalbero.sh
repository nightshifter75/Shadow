#!/bin/sh

cp outfile albero
touch decodificato
CODICI=$(cat $HOME/Shadow/script/opere.dat | cut -d" " -f1 | cut -d"/" -f6)
DECODIFICATI=$(cat $HOME/Shadow/script/opere.dat | cut -d" " -f1 | cut -d"/" -f6 | wc -l)
# Estraggo i codici da opere.dat
	
for CODICE in $CODICI; do

	NOME=$(grep $CODICE < $HOME/Shadow/script/opere.dat | cut -d" " -f2 | cut -d"/" -f6)
	echo "Eseguo la decodifica per il codice "$CODICE" del nome "$NOME"..."
	cat albero | sed s/$CODICE/$NOME/g > decodificato
	cp decodificato albero

done
# Per ogni CODICE dei CODICI mutua un NOME.

rm decodificato

echo ""
echo "Nomi decodificati:"$DECODIFICATI"."
