#!/bin/sh

ELENCO=$(find $HOME/Shadow -name "*.xml")
EPURATI=$(find $HOME/Shadow -name "*.xml" | wc -l)
mkdir $HOME/Shadow/epurati 2>/dev/null
# Creo l'ELENCO dei file da epurare e la cartella epurati.

for ELEMENTO in $ELENCO; do

    echo "Epuro il file "$ELEMENTO"..."

    NOME=$(echo $ELEMENTO | xargs basename | cut -d"." -f1)

    echo $( # tutto su una linea

        cat $ELEMENTO |                             # carica il file xml
        grep line |                                 # seleziona solo linee con le battute
        sed s/"\<italic\>"/""/g |                   # toglie il tag italic di apertura
        sed s/"\<\/italic\>"/""/g |                 # toglie il tag italic di chiusura
        sed s/"\<noitalic\>"/""/g |                 # toglie il tag noitalic di apertura
        sed s/"\<\/noitalic\>"/""/g |               # toglie il tag noitalic di chiusura
        sed s/"\<name type=\"person\"\>"/""/g |     # toglie il tag name di apertura
        sed s/"\<\/name\>"/""/g |                   # toglie il tag name di chiusura
        sed s/"\<nameref\>"/""/g |                  # toglie il tag nameref di apertura
        sed s/"\<\/nameref\>"/""/g |                # toglie il tag nameref di chiusura
        sed s/"\<dropcap\>"/""/g                 |  # toglie il tag dropcap di apertura
        sed s/"\<dropcap type=\"floral\"\>"/""/g |  # toglie il tag dropcap floral di apertura
        sed s/"\<\/dropcap\>"/""/g |                # toglie il tag dropcap di chiusura
        sed s/"\<foreign xml\:lang=\"la\"\>"/""/g | # toglie il tag foreign di apertura
        sed s/"\<\/foreign\>"/""/g |                # toglie il tag foreign di chiusura
        cut -d">" -f2 |                             # toglie il tag line di apertura
        sed s/"\<\/line"//g |                       # toglie il tag line di chiusura
        sed s/"&#34;"/""/g |                        # toglie l'entity " tipografico
        sed s/"&#38;"/"&"/g |                       # sostituisce l'entity & tipografico
        sed s/"&amp;"/"&"/g |                       # sostituisce l'entity & tipografico
        sed s/"&#198;"/"ae"/g |                     # sostituisce l'entity Æ tipograficusura
        sed s/"&#230;"/"ae"/g |                     # sostituisce l'entity æ tipograficusura
        sed s/"&#244;"/"o"/g |                      # sostituisce l'entity ô tipografico
        sed s/"&#253;"/"the"/g |                    # sostituisce l'entity ý (the) tipografico
        sed s/"&#333;"/"om"/g |                     # sostituisce l'entity ō (om) tipografico
        sed s/"&#339;"/"oe"/g |                     # sostituisce l'entity œ tipograficusura
        sed s/"&#383;"/"s"/g |                      # sostituisce l'entity s tipografico
        sed s/"&#392;"/"c"/g |                      # sostituisce l'entity c[t] tipografico
        sed s/"&#392; t"/"ct"/g |                   # sostituisce l'entity ct tipografico
        sed s/"&#1267;"/"thou"/g |                  # sostituisce l'entity ӳ (thou) tipografico
        sed s/"&#7811;"/"which"/g |                 # sostituisce l'entity ẃ (which) tipografico
        sed s/"&#8212;"/"-"/g |                     # sostituisce l'entity - semilineato tipografico sostituito -
        sed s/"&#8213;"/"-"/g |                     # sostituisce l'entity - semilineato tipografico sostituito -
        sed s/"&#8216;"/"\'"/g |                    # sostituisce l'entity ' aperta sostitutita con '
        sed s/"&#8217;"/"\'"/g |                    # sostituisce l'entity ' chiusa sostitutita con '
        sed s/"&#8220;"/""/g |                      # toglie l'entity " aperti tipografico
        sed s/"&#8221;"/""/g |                      # toglie l'entity " aperti tipografico
        sed s/"&#64256;"/"ff"/g |                   # sostituisce l'entity ff tipografico
        sed s/"&#64257;"/"fi"/g |                   # sostituisce l'entity fi tipografico
        sed s/"&#64258;"/"fl"/g |                   # sostituisce l'entity fl tipografico
        sed s/"&#64259;"/"ffi"/g |                  # sostituisce l'entity ffi tipografico
        sed s/"&#64260;"/"ffl"/g |                  # sostituisce l'entity ffl tipografico
        sed s/"&#64261;"/"ft"/g |                   # sostituisce l'entity ft tipografico
        sed s/"[\,\.\:\;\!\?\—\-]"/" "/g |          # sostituisce i segni di interpunzione e i trattini con uno spazio
        sed s/"("/""/g |                            # toglie le parentesi tonde
        sed s/")"/""/g |                            # toglie le parentesi tonde
        sed s/"\["/""/g |                           # toglie le parentesi quadre
        sed s/"\]"/""/g |                           # toglie le parentesi quadre
        sed s/"\""/""/g |                           # toglie i doppi apici
        sed s/" -"/" "/g |                          # sostituisce i dash spaziati con uno spazio
        sed s/"- "/" "/g |                          # sostituisce i dash spaziati con uno spazio
        sed s/" - "/" "/g |                         # sostituisce i dash spaziati con uno spazio
        sed s/"- "/" "/g |                          # sostituisce i dash spaziati con uno spazio
        sed s/" -"/" "/g |                          # sostituisce i dash spaziati con uno spazio
        sed s/" - "/" "/g |                         # sostituisce i dash spaziati con uno spazio
        tr "[:upper:]" "[:lower:]"                  # tutto minuscolo

    ) > $HOME/Shadow/epurati/$NOME.txt
    
done
# Per ogni ELEMENTO dell'ELENCO estraggo il NOME dal file xml dell'opera da epurare, la epuro e la scrivo con il NOME.txt nella cartella degli epurati.

echo ""
echo "File epurati:"$EPURATI"."
