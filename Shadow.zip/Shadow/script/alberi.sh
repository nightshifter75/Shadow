find $HOME/Shadow -name "albero" | xargs open
