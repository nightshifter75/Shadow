#!/bin/sh

ELENCO=$(ls $HOME/Shadow/esperimenti/???_??)
SPLITTATI=$(ls $HOME/Shadow/esperimenti/???_?? | wc -l)
BYTE=32768
mkdir $HOME/Shadow/esperimenti/$BYTE 2> /dev/null
# Creo l'ELENCO dei file da splittare e la cartella dei frammenti.

for ELEMENTO in $ELENCO; do
	echo "Eseguo lo split di "$ELEMENTO"..."
	split -b ${BYTE} ${ELEMENTO} ${ELEMENTO} 2> /dev/null
done
# Eseguo lo split per ogni ELEMENTO dell'ELENCO.

echo ""
echo "Raggruppo i frammenti..."
mv `ls -l $HOME/Shadow/esperimenti/???_???? | grep $BYTE | awk '{print $9}'` $HOME/Shadow/esperimenti/$BYTE/.
# Metto i frammenti nella cartella.

echo "Raggruppo i resti..."
mkdir $HOME/Shadow/esperimenti/resti$BYTE 2> /dev/null
mv $HOME/Shadow/esperimenti/???_???? $HOME/Shadow/esperimenti/resti$BYTE/.
# Creo la cartella dei resti e sposto i resti.

echo ""
echo "File splittati:"$SPLITTATI"."
