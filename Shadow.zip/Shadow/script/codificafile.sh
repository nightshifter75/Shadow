#!/bin/sh

ELENCO=$(ls $HOME/Shadow/epurati/*.txt)
CODIFICATI=$(ls $HOME/Shadow/epurati/*.txt | wc -l)
mkdir $HOME/Shadow/esperimenti/ 2> /dev/null
# Creo l'ELENCO dei file da codificare e la cartella degli esperimenti.

for NOME in $ELENCO; do

	BASE=$(basename $NOME | cut -d"." -f1)
	CODICE=$(cat $HOME/Shadow/script/opere.dat | grep -w $BASE | cut -d" " -f1)
	echo "Codifico "$NOME" in "$CODICE"..." 
	cp $NOME $HOME/Shadow/esperimenti/$CODICE

done
# Per ogni NOME dell'ELENCO mutua un CODICE e rinomina il file.

echo ""
echo "File codificati:"$CODIFICATI"."
